package ru.aviasales.appodeallib;

import com.appodeal.ads.InterstitialCallbacks;

public class InterstitialCallbacksAdapter implements InterstitialCallbacks {
	@Override
	public void onInterstitialLoaded(boolean b) {

	}

	@Override
	public void onInterstitialFailedToLoad() {

	}

	@Override
	public void onInterstitialShown() {

	}

	@Override
	public void onInterstitialClicked() {

	}

	@Override
	public void onInterstitialClosed() {

	}
}
