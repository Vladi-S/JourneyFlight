package ru.aviasales.appodeallib;

import com.appodeal.ads.NativeAd;
import com.appodeal.ads.NativeCallbacks;

import java.util.List;

public class NativeCallbacksAdapter implements NativeCallbacks {
	@Override
	public void onNativeLoaded(List<NativeAd> list) {

	}

	@Override
	public void onNativeFailedToLoad() {

	}

	@Override
	public void onNativeShown(NativeAd nativeAd) {

	}

	@Override
	public void onNativeClicked(NativeAd nativeAd) {

	}
}
