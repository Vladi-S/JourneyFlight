package ru.aviasales.template.ui.listener;

public interface OnRangeChangeListener {
	void onChange(int max);
}
